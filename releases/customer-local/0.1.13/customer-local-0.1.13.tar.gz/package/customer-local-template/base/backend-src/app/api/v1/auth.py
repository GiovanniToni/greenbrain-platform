from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import (
    create_access_token,
    decode_token,
    hash_password,
    verify_password,
)
from app.db.session import get_db
from app.db.users import (
    count_users,
    create_admin_user,
    create_user,
    get_user_by_email,
    update_last_login,
)

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])

_bearer = HTTPBearer()
SSO_ALGORITHM = "HS256"


class LoginRequest(BaseModel):
    email: str
    password: str


class SetupRequest(BaseModel):
    email: str
    password: str
    full_name: str | None = None


class AdminUserCreateRequest(BaseModel):
    email: str
    password: str
    full_name: str | None = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class UserResponse(BaseModel):
    id: str
    email: str
    full_name: str | None
    is_admin: bool
    tenant_code: str | None = None
    home_host: str | None = None
    home_path: str | None = None
    user_role: str | None = None


class SsoStartResponse(BaseModel):
    redirect_url: str
    target_host: str
    target_path: str


class SsoExchangeRequest(BaseModel):
    ticket: str


def _build_sso_ticket(user: dict) -> str:
    now = datetime.now(timezone.utc)
    exp = now + timedelta(minutes=2)

    home_host = (user.get("home_host") or "").strip()
    home_path = (user.get("home_path") or "/dashboard").strip() or "/dashboard"

    payload = {
        "sub": user["email"],
        "email": user["email"],
        "full_name": user.get("full_name"),
        "is_admin": bool(user.get("is_admin")),
        "tenant_code": user.get("tenant_code"),
        "home_host": home_host,
        "home_path": home_path,
        "user_role": user.get("user_role"),
        "purpose": "greenbrain_sso",
        "iss": "greenbrain_auth",
        "aud": home_host,
        "exp": exp,
        "iat": now,
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=SSO_ALGORITHM)


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer),
    db: Session = Depends(get_db),
) -> dict:
    try:
        email = decode_token(credentials.credentials)
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = get_user_by_email(db, email)
    if not user or not user["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Not authenticated",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


def require_admin(user: dict = Depends(get_current_user)) -> dict:
    if not user.get("is_admin"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required",
        )
    return user


@router.post("/login", response_model=TokenResponse)
def login(body: LoginRequest, db: Session = Depends(get_db)):
    user = get_user_by_email(db, body.email)
    if not user or not verify_password(body.password, user["hashed_password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )
    if not user["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account disabled",
        )

    update_last_login(db, str(user["id"]))
    token = create_access_token(subject=user["email"])
    return TokenResponse(
        access_token=token,
        expires_in=settings.jwt_expire_minutes * 60,
    )


@router.post("/sso/start", response_model=SsoStartResponse)
def sso_start(body: LoginRequest, db: Session = Depends(get_db)):
    user = get_user_by_email(db, body.email)
    if not user or not verify_password(body.password, user["hashed_password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
        )
    if not user["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account disabled",
        )

    home_host = (user.get("home_host") or "").strip()
    home_path = (user.get("home_path") or "/dashboard").strip() or "/dashboard"

    if not home_host:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing home_host for user",
        )

    ticket = _build_sso_ticket(user)
    redirect_url = f"https://{home_host}/login?sso={ticket}"

    return SsoStartResponse(
        redirect_url=redirect_url,
        target_host=home_host,
        target_path=home_path,
    )



@router.post("/sso/exchange", response_model=TokenResponse)
def sso_exchange(body: SsoExchangeRequest, request: Request, db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(
            body.ticket,
            settings.jwt_secret,
            algorithms=[SSO_ALGORITHM],
            audience=request.headers.get("host", "").split(":")[0],
        )
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid SSO ticket",
        )

    if payload.get("purpose") != "greenbrain_sso":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid SSO ticket",
        )

    email = (payload.get("email") or "").strip().lower()
    if not email:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid SSO ticket",
        )

    user = get_user_by_email(db, email)
    if not user or not user["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not enabled on tenant",
        )

    update_last_login(db, str(user["id"]))
    token = create_access_token(subject=user["email"])
    return TokenResponse(
        access_token=token,
        expires_in=settings.jwt_expire_minutes * 60,
    )

@router.get("/me", response_model=UserResponse)
def me(user: dict = Depends(get_current_user)):
    return UserResponse(
        id=str(user["id"]),
        email=user["email"],
        full_name=user.get("full_name"),
        is_admin=bool(user["is_admin"]),
        tenant_code=user.get("tenant_code"),
        home_host=user.get("home_host"),
        home_path=user.get("home_path"),
        user_role=user.get("user_role"),
    )


@router.post(
    "/setup",
    status_code=status.HTTP_201_CREATED,
    response_model=UserResponse,
)
def setup(body: SetupRequest, db: Session = Depends(get_db)):
    if count_users(db) > 0:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Setup already completed",
        )

    user = create_user(
        db,
        email=body.email,
        hashed_password=hash_password(body.password),
        full_name=body.full_name,
        is_admin=True,
    )

    return UserResponse(
        id=str(user["id"]),
        email=user["email"],
        full_name=user.get("full_name"),
        is_admin=bool(user["is_admin"]),
        tenant_code=user.get("tenant_code"),
        home_host=user.get("home_host"),
        home_path=user.get("home_path"),
        user_role=user.get("user_role"),
    )


@router.post("/admin-users", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def create_admin_user_route(
    body: AdminUserCreateRequest,
    _: dict = Depends(require_admin),
    db: Session = Depends(get_db),
):
    email = body.email.lower().strip()
    if get_user_by_email(db, email):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="User already exists",
        )

    if len(body.password) < 8:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password must be at least 8 characters",
        )

    user = create_admin_user(
        db,
        email=email,
        hashed_password=hash_password(body.password),
        full_name=body.full_name,
    )

    return UserResponse(
        id=str(user["id"]),
        email=user["email"],
        full_name=user.get("full_name"),
        is_admin=bool(user["is_admin"]),
        tenant_code=user.get("tenant_code"),
        home_host=user.get("home_host"),
        home_path=user.get("home_path"),
        user_role=user.get("user_role"),
    )
